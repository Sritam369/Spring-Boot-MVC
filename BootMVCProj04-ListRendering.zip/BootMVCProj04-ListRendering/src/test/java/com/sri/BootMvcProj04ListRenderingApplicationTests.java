package com.sri;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootMvcProj04ListRenderingApplicationTests {

	@Test
	void contextLoads() {
	}

}
